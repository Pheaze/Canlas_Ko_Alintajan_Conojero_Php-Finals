<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-weight: bold;
}
.style2 {font-size: 14px}
-->
</style>
 <div class="footer">
          <div class="style1"> <p align="center" class="style2"> Copyright &copy; <?php echo date('Y'); ?> | Monday, Goodness |H/F2021/COM/001 | Design and Implementation of a Product Expiry Alert Management System | </p>
</div>
</div>
